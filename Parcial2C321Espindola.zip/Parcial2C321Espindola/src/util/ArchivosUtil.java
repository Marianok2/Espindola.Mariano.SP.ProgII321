package util;

import java.io.File;

public interface ArchivosUtil {
    static void crearCarpetaSiNoExiste(String path) {
        File carpeta = new File(path);
        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }
    }
}
