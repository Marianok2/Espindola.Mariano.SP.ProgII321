
package config;

public interface AppConfig {
    String PATH_DATA = "src/data/";
    String ARCHIVO_BINARIO = PATH_DATA + "robots.dat";
    String ARCHIVO_CSV = PATH_DATA + "robots.csv";
    String ARCHIVO_TXT = PATH_DATA + "reporte_robots.txt";
    String TITULO_REPORTE = "REPORTE DE ROBOTS DE RESCATE";
}
