
package persistence;

@FunctionalInterface
public interface CSVSerializable {
    String toCSV(); 
}