package service;

import java.util.Collection;
import model.RobotRescate;
import model.TipoRobot;

public interface ServicioRobots { 

    static void mostrarRobots(Collection<? extends RobotRescate> robots) {
        for (RobotRescate r : robots) {
            System.out.println(r);
        }
    }

    static void cargarRobotsDePrueba(Collection<? super RobotRescate> destino) {
        destino.add(new RobotRescate(99, "DemoBot-X", "TestLabs", 60, TipoRobot.EXPLORADOR));
        destino.add(new RobotRescate(100, "DemoBot-Y", "TestLabs", 45, TipoRobot.TERRESTRE));
    }
}