package model;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Function;
import persistence.CSVSerializable;


public class CentroRescate<T extends CSVSerializable & Serializable & Comparable<T>> implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<T> lista;

    public CentroRescate() {
       lista = new ArrayList<>();
    }

    public void agregar(T elemento) {
        lista.add(elemento); 
    }
    public T obtener(int indice) {
        return lista.get(indice); 
    } 
    public void eliminar(int indice) {
        lista.remove(indice); 
    } 
    public List<T> obtenerTodos() {
        return new ArrayList<>(lista); 
    } 

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T e : lista) {
            if (criterio.test(e)) {
                filtrados.add(e);
            }
        }
        return filtrados;
    }

    public void paraCadaElemento(Consumer<? super T> accion) { 
        lista.forEach(accion);
    }

    public void ordenar() { 
        Collections.sort(lista);
    }

    public void ordenar(Comparator<? super T> comparador) { 
        lista.sort(comparador);
    }

    
 
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
        }
    }


    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException { 
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            lista = (List<T>) ois.readObject();
        }
    }

   
    public void guardarEnCSV(String ruta, String encabezado) throws IOException { 
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            bw.write(encabezado);
            bw.newLine();
            for (T elemento : lista) {
                bw.write(elemento.toCSV());
                bw.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> mapeador) throws IOException { 
        this.lista.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            boolean esPrimeraLinea = true;
            while ((linea = br.readLine()) != null) {
                if (esPrimeraLinea) {
                    esPrimeraLinea = false;
                    continue; 
                }
                if (!linea.trim().isEmpty()) {
                    this.lista.add(mapeador.apply(linea));
                }
            }
        }
    }

 
    public void exportarTXT(String ruta, String titulo) throws IOException { 
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            bw.write(titulo);
            bw.newLine();
            for (T elemento : lista) {

                if(elemento instanceof RobotRescate) {
                    RobotRescate r = (RobotRescate) elemento;
                    bw.write("ID: " + r.getId()); bw.newLine(); 
                    bw.write("Modelo: " + r.getModelo()); bw.newLine();
                    bw.write("Fabricante: " + r.getFabricante()); bw.newLine(); 
                    bw.write("Autonomía: " + r.getAutonomiaMinutos() + " minutos"); bw.newLine();
                    bw.write("Tipo: " + r.getTipo().name()); bw.newLine();
                    bw.newLine();
                }
            }
        }
    }
}
