package model;

import java.io.Serializable;
import persistence.CSVSerializable;
/**
 * Representa un robot de rescate dentro del sistema.
 * Implementa interfaces para persistencia en archivos y ordenamiento natural.
 */
public class RobotRescate implements Comparable<RobotRescate>, Serializable, CSVSerializable {

    private static final long serialVersionUID = 1L;
    private static final String CSV_HEADER = "id,modelo,fabricante,autonomiaMinutos,tipo";
    private int id;
    private String modelo;
    private String fabricante;
    private int autonomiaMinutos;
    private TipoRobot tipo;
    /**
     * Constructor completo para crear un nuevo robot.
     */
    public RobotRescate(int id, String modelo, String fabricante, int autonomiaMinutos, TipoRobot tipo) {
        this.id = id;
        this.modelo = modelo;
        this.fabricante = fabricante;
        this.autonomiaMinutos = autonomiaMinutos;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getModelo() {
        return modelo;
    }

    public String getFabricante() {
        return fabricante;
    }

    public int getAutonomiaMinutos() {
        return autonomiaMinutos;
    }

    public TipoRobot getTipo() {
        return tipo;
    }
    /**
     * @return El encabezado esperado para archivos CSV.
     */
    public static String getCSVHeader() {
        return CSV_HEADER;
    }
    /**
     * Define el ordenamiento natural basado en el ID del robot.
     */
    @Override
    public int compareTo(RobotRescate r) {
        return Integer.compare(id, r.id);
    }
    /**
     * Convierte los atributos del robot a formato CSV.
     */
    @Override
    public String toCSV() {
        return id + "," + modelo + "," + fabricante + "," + autonomiaMinutos + "," + tipo;
    }
/**
     * Fábrica para crear un RobotRescate desde una línea CSV.
     * @param robotCSV La línea de texto con los datos.
     * @return Un objeto RobotRescate instanciado.
     * @throws IllegalArgumentException si los datos son inválidos o faltan campos.
     */
public static RobotRescate fromCSV(String robotCSV) {
    
    validarCSV(robotCSV);
    String[] partes = robotCSV.split(",");
    validarLargoCSV(partes);
    
    return construirRobot(partes);
}

private static void validarLargoCSV(String[] partes) {

    if (partes.length != 5) {
        throw new IllegalArgumentException("Formato inválido: se esperaban 5 campos.");
    }
}
private static void validarCSV(String linea) {
    if (linea == null || linea.trim().isEmpty()) {
        throw new IllegalArgumentException("La línea está vacía.");
    }
}
    /**
     * Intenta construir el objeto validando tipos de datos y restricciones de negocio.
     */
private static RobotRescate construirRobot(String[] partes) {
    try {
        int id = Integer.parseInt(partes[0].trim());
        String modelo = partes[1].trim();
        String fabricante = partes[2].trim();
        int autonomia = Integer.parseInt(partes[3].trim());
        
        if (autonomia < 0) {
            throw new IllegalArgumentException("La autonomía no puede ser negativa.");
        }

        TipoRobot tipo = TipoRobot.valueOf(partes[4].trim().toUpperCase());
        
        return new RobotRescate(id, modelo, fabricante, autonomia, tipo);
        
    } catch (NumberFormatException e) {
        throw new IllegalArgumentException("Error en el formato numérico: " + e.getMessage());
    }
}

    @Override
    public String toString() {
        return String.format("RobotRescate{id=%d, modelo=%s, fabricante=%s, autonomiaMinutos=%d, tipo=%s}",
                id, modelo, fabricante, autonomiaMinutos, tipo);
    }
}
