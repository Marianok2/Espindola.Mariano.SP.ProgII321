
package model;


public enum TipoRobot {
    TERRESTRE,
    AEREO,
    ACUATICO,
    MEDICO,
    EXPLORADOR,
    CARGA
}
