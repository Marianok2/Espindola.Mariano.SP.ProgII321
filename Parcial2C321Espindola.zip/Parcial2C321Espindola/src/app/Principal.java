package app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import config.AppConfig;
import model.CentroRescate;
import model.RobotRescate;
import model.TipoRobot;
import service.ServicioRobots;
import util.ArchivosUtil;

public class Principal {
    public static void main(String[] args) {
        try {
           
            ArchivosUtil.crearCarpetaSiNoExiste(AppConfig.PATH_DATA);

            CentroRescate<RobotRescate> centro = new CentroRescate<>(); 
            
            centro.agregar(new RobotRescate(1, "RX-Terra", "Boston Dynamics", 140, TipoRobot.TERRESTRE)); 
            centro.agregar(new RobotRescate(2, "MediBot Pro", "RescueTech", 180, TipoRobot.MEDICO)); 
            centro.agregar(new RobotRescate(3, "SkyScan RX", "AeroSafe", 100, TipoRobot.AEREO)); 
            centro.agregar(new RobotRescate(4, "DeepRescue", "Oceanic Labs", 160, TipoRobot.ACUATICO));
            centro.agregar(new RobotRescate(5, "CargoMax", "Boston Dynamics", 120, TipoRobot.CARGA));
            centro.agregar(new RobotRescate(6, "Explorer Mini", "RescueTech", 80, TipoRobot.EXPLORADOR)); 

            System.out.println("ROBOTS CARGADOS:"); 
            centro.paraCadaElemento(r -> System.out.println(r)); 

            System.out.println("\nROBOTS DE TIPO MEDICO:"); 
            centro.filtrar(r -> r.getTipo() == TipoRobot.MEDICO) 
                  .forEach(r -> System.out.println(r)); 

            System.out.println("\nROBOTS CON AUTONOMÍA MAYOR O IGUAL A 120 MINUTOS:"); 
            centro.filtrar(r -> r.getAutonomiaMinutos() >= 120) 
                  .forEach(r -> System.out.println(r)); 

            System.out.println("\nROBOTS CUYO MODELO CONTIENE 'RX':"); 
            centro.filtrar(r -> r.getModelo().contains("RX")) 
                  .forEach(r -> System.out.println(r)); 

            System.out.println("\nROBOTS ORDENADOS POR ID:"); 
            centro.ordenar(); 
            centro.paraCadaElemento(r -> System.out.println(r)); 

            System.out.println("\nROBOTS ORDENADOS POR MODELO:"); 
            centro.ordenar((r1, r2) -> r1.getModelo().compareTo(r2.getModelo())); 
            centro.paraCadaElemento(r -> System.out.println(r)); 

            System.out.println("\nROBOTS ORDENADOS POR AUTONOMÍA DE MAYOR A MENOR:"); 
            centro.ordenar((r1, r2) -> Integer.compare(r2.getAutonomiaMinutos(), r1.getAutonomiaMinutos())); 
            centro.paraCadaElemento(r -> System.out.println(r)); 

            System.out.println("\nROBOTS ORDENADOS POR FABRICANTE Y, EN CASO DE EMPATE, POR AUTONOMÍA:"); 
            centro.ordenar((r1, r2) -> { 
                int cmp = r1.getFabricante().compareTo(r2.getFabricante()); 
                if (cmp == 0) { 
                    return Integer.compare(r1.getAutonomiaMinutos(), r2.getAutonomiaMinutos());
                }
                return cmp;
            });
            centro.paraCadaElemento(r -> System.out.println(r)); 

            
            centro.guardarEnArchivo(AppConfig.ARCHIVO_BINARIO); 
            
            CentroRescate<RobotRescate> centroCargadoBinario = new CentroRescate<>(); 
            centroCargadoBinario.cargarDesdeArchivo(AppConfig.ARCHIVO_BINARIO); 
            System.out.println("\nROBOTS CARGADOS DESDE ARCHIVO BINARIO:"); 
            centroCargadoBinario.paraCadaElemento(r -> System.out.println(r)); 

            centro.guardarEnCSV(AppConfig.ARCHIVO_CSV, RobotRescate.getCSVHeader()); 
            
            CentroRescate<RobotRescate> centroCargadoCSV = new CentroRescate<>(); 
            centroCargadoCSV.cargarDesdeCSV(AppConfig.ARCHIVO_CSV, linea -> RobotRescate.fromCSV(linea)); 
            System.out.println("\nROBOTS CARGADOS DESDE ARCHIVO CSV:"); 
            centroCargadoCSV.paraCadaElemento(r -> System.out.println(r)); 

            centro.exportarTXT(AppConfig.ARCHIVO_TXT, AppConfig.TITULO_REPORTE); 

            
            System.out.println("\nMOSTRAR ROBOTS USANDO SERVICIO:"); 
            List<? extends RobotRescate> robotsParaMostrar = centro.obtenerTodos(); 
            ServicioRobots.mostrarRobots(robotsParaMostrar);

            System.out.println("\nCARGAR ROBOTS DE PRUEBA USANDO SERVICIO:");
            List<RobotRescate> robotsDemo = new ArrayList<>(); 
            ServicioRobots.cargarRobotsDePrueba(robotsDemo); 
            
            for (RobotRescate robot : robotsDemo) { 
                centro.agregar(robot); 
            }
            
            System.out.println("\nROBOTS LUEGO DE AGREGAR LOS DE PRUEBA:");
            centro.paraCadaElemento(r -> System.out.println(r));


            List<? super RobotRescate> destinoGenerico = new ArrayList<Object>();
            ServicioRobots.cargarRobotsDePrueba(destinoGenerico); 

        } catch (IOException | ClassNotFoundException e) { 
            System.err.println("Error de archivo: " + e.getMessage()); 
        }
    }
}